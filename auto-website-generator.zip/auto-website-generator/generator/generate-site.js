// generator/generate-site.js
// Gebruik: node generator/generate-site.js prompt.json dist
const fs = require('fs');
const path = require('path');

function ensureDir(p) { if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); }

function renderHTML(data) {
  const title = data.site_name || 'Mijn Website';
  const color = data.brand_color || '#0ea5e9';
  const sections = Array.isArray(data.sections) ? data.sections : [];
  const cta = data.cta || { text: 'Neem contact op', href: '#' };

  const nav = sections.map(s => `<a href="#${s.id}">${s.title}</a>`).join(' ');
  const body = sections.map(s => `
    <section id="${s.id}" style="padding:48px 0;border-bottom:1px solid #eee">
      <h2 style="margin:0 0 12px 0">${s.title}</h2>
      <p>${s.content || ''}</p>
    </section>
  `).join('\n');

  return `<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${title}</title>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
  <style>
    html,body{margin:0;padding:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,'Helvetica Neue',Arial}
    .container{max-width:1100px;margin:0 auto;padding:0 20px}
    .btn{display:inline-block;padding:12px 18px;border-radius:12px;text-decoration:none}
    header{background:${color};color:white;padding:18px 0}
    header a{color:white;text-decoration:none;margin-right:16px;font-weight:600}
    .hero{padding:64px 0}
    .footer{padding:48px 0;color:#777}
  </style>
</head>
<body>
  <header>
    <div class="container">
      <strong>${title}</strong>
      <nav style="float:right">${nav}</nav>
      <div style="clear:both"></div>
    </div>
  </header>

  <main class="container">
    <section class="hero">
      <h1 style="font-size:42px;margin:0 0 12px 0">${data.hero?.headline || title}</h1>
      <p style="max-width:700px">${data.hero?.subheadline || 'Snel online met een moderne website.'}</p>
      <p style="margin-top:18px">
        <a class="btn" href="${cta.href}" style="background:black;color:white">${cta.text}</a>
      </p>
    </section>

    ${body}
  </main>

  <div class="footer container">
    © ${new Date().getFullYear()} ${title}
  </div>
</body>
</html>`;
}

(function main() {
  const [, , promptPath, outDir] = process.argv;
  if (!promptPath || !outDir) {
    console.error('Usage: node generator/generate-site.js prompt.json dist');
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(promptPath, 'utf8'));
  const dist = path.resolve(outDir);
  ensureDir(dist);
  fs.writeFileSync(path.join(dist, 'index.html'), renderHTML(data), 'utf8');

  // Extra pagina's indien opgegeven
  if (Array.isArray(data.pages)) {
    data.pages.forEach(p => {
      const html = `<!doctype html><meta charset="utf-8"><title>${p.title}</title>${p.html || '<h1>Lege pagina</h1>'}`;
      fs.writeFileSync(path.join(dist, `${p.slug || 'pagina'}.html`), html, 'utf8');
    });
  }
  console.log('Site generated in', dist);
})();
