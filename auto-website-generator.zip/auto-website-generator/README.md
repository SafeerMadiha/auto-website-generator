# Prompt → Site → Live

Zet deze repo online en start de GitHub Action **Generate & Deploy Site** met jouw JSON-prompt.

## Snelstart
1) Link deze repo aan Vercel of Netlify (publish dir = `public`).
2) In GitHub → **Actions** → *Generate & Deploy Site* → **Run workflow** → plak jouw JSON-prompt.
3) Of open een Issue met label `deploy` en als body jouw JSON-prompt.

## Voorbeeld-prompt
Zie `prompt.example.json`.
